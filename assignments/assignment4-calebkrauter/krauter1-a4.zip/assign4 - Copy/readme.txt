Dependencies and start proceedure;
o npm init –y 
o npm i express nodemon mysql cors 
o npm start

Source for data set. 
o ChatGPT 3.5
Based on the following prompt: 
"-- INSERT INFO `cpus` (`cpuBrand`, `price`,  `coreCount`,  `speed`, `socketType`, `condition`) VALUES,
I need 20 lines like this with random input for each of the variables.
Cpu brands include Intel, AMD and ARM.
You decide prices based on last known knowledge.
Core count includes 4,6,8,16.
Speed based on your last known knowledge.
Socket Type LGA or PGA.
Condition is New, used or renewed.
The serial number should be unique and random on each and only be 6 integers long.
Some of the cpus should have same brand, price, core count and speed and socket type 
and condition with the exception of the serial number.
Data population is generated from ChatGPT 3.5 based on the following prompt:"